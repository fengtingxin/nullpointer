﻿section: control
id: divider
description: 水平分割线
icon: —
filter: fengexian fgx
---

# 分隔线

## 水平分隔线

<div class="example">
  <hr>
</div>

```
<hr>
```
