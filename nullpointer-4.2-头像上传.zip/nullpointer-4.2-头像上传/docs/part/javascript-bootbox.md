﻿section: javascript
id: bootbox
description: 警告、确认和内容编辑模态框
icon: icon-question-sign
filter: motaiduihuakuang mtdhk
---

# 模态对话框 (Bootbox)

Bootbox用来替代系统内置对话框，并于[模态框](#javascript/modal)保持一致的外观。

具体用法请参考[官方网站](http://bootboxjs.com/#)。

