﻿section: javascript
id: scrollspy
description: 根据滚动条所处的位置来自动更新导航项
icon: icon-link
filter: gundongjianting gdjt
---

# 滚动监听

滚动监听插件是Bootstrap中的一个插件，用来根据滚动条所处的位置来自动更新导航项的。

具体用法请参考[Bootstrap官方文档](http://getbootstrap.com/javascript/#scrollspy)（[中文版本](http://v3.bootcss.com/javascript/#scrollspy)）。
